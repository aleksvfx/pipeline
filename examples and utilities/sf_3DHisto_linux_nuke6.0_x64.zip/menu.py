import nuke

nodesmenu = nuke.menu("Nodes")
slyfoxmenu = nodesmenu.addMenu("SlyfoxFX","slyfoxfx.png")
slyfoxmenu.addCommand("sf_3DHisto", "nuke.createNode(\"sf_3DHisto\")")