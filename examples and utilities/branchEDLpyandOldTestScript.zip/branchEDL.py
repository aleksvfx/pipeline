def wonderEDL():

    sn = nuke.selectedNode()
    edlFile = nuke.getFilename("Wonder Branch", "*.edl")
    edl = open(edlFile)
    pat1 = re.compile("TITLE|AA|\*")
    pat2 = re.compile("[\s]*")
    appendNodes = []

    for line in edl:
        if pat1.search(line) is not None:
            continue
        elif line.isspace():
            continue
        else:
            l = pat2.split(line)
            edit = int(l[0])
            reel = l[1]
            srcIN = int(l[4])
            srcOUT = int(l[5])
            recIN = int(l[6])
            recOUT = int(l[7])

            r = nuke.createNode("Retime", inpanel=False)
            r['input.first_lock'].setValue(True)
            r['input.last_lock'].setValue(True)
            r['input.first'].setValue(recIN)
            r['input.last'].setValue(recOUT)
            r['output.first_lock'].setValue(True)
            r['output.last_lock'].setValue(True)
            r['output.first'].setValue(1)
            r['output.last'].setValue((recOUT-recIN)+1)
            r['before'].setValue('black')
            r['after'].setValue('black')
            r['label'].setValue(str(edit)+"\n"+reel)
            r.setInput(0, sn)
            appendNodes.append(r)

    ### Append Stuff
    for n in appendNodes:
        n['selected'].setValue(False)
    for n in appendNodes:
        n['selected'].setValue(True)
    nuke.createNode("AppendClip", inpanel=False)
wonderEDL()